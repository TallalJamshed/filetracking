<?php
    use App\FilesData;
    use App\TrackingData;

    // use Auth;
    
    class Helper {

        public static function cardData() { 
            if(Auth::user()->fk_role_id == 1){
                $data = array(
                    "total" => FilesData::count(),
                    "active" => FilesData::where('status','active')->count(),
                    "finished" => FilesData::where('status','finished')->count(),
                    "pending" => FilesData::where('status','pending')->count()
                    
                );
            }else{
                $total = FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->orWhere('trackingdata.fk_user_id',Auth::user()->user_id)->count();
                $active = FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->orWhere('trackingdata.fk_user_id',Auth::user()->user_id)->where('filedata.status','active')->count();
                $finished1 = FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->where('filedata.status','finished')->count();
                $finished2 = FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->Where('trackingdata.fk_user_id',Auth::user()->user_id)->where('filedata.status','finished')->count();
                $pending1 = FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->where('filedata.status','pending')->count();
                $pending2 = FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->Where('trackingdata.fk_user_id',Auth::user()->user_id)->where('filedata.status','pending')->count();
                $data = array(
                    "total" => $total,
                    "active" => $active,
                    "finished" => $finished1 + $finished2,
                    "pending" => $pending1 + $pending2
                );
            }
            // dd($data);
            return $data;
        }

        public static function navbarData(){
            
            $data = array(
                "nooffiles" => TrackingData::join('filedata','filedata.file_id','trackingdata.fk_file_id')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->where('filedata.status','active')->where('date_recieved',null)->count(),
            );
            return $data;
        }
    }
?>