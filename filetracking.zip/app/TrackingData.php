<?php

namespace App;
use Auth;

use Illuminate\Database\Eloquent\Model;

class TrackingData extends Model
{
    protected $table = "trackingdata";
    protected $primaryKey = "track_id";
    protected $fillable = [
        "fk_file_id" , "fk_department_id" , "fk_position_id" , "track_name" , "fk_user_id" , "track_date" , "comments" 
    ];

    public static function saveTrackData($request , $id){
        $trackdata = new TrackingData;
        $trackdata->fill($request->all());
        $trackdata->track_date = date('Y-m-d');
        $trackdata->fk_user_id = Auth::user()->user_id;
        $trackdata->fk_file_id = $id;
        $trackdata->save();
    }

    // public static function updateFiles($request){

    // }
}
