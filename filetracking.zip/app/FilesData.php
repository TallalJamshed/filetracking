<?php

namespace App;
use Auth;
use App\TrackingData;
use DB;

use Illuminate\Database\Eloquent\Model;

class FilesData extends Model
{
    protected $table = "filedata";
    protected $primaryKey = "file_id";
    protected $fillable = [
         "date_added" ,"date_recieved", "date_finished" , "status"  , "subject" , "created_by"
    ];
    
    public static function getFiles(){
        if(Auth::user()->fk_role_id == 1){
            // $lastdepart = TrackingData::groupBy('fk_file_id')->orderBy('created_at','ASC')->get();
            // dd($lastdepart);
            $activefiles = FilesData::where('status','active')->get();
            // $trackids = [];
            foreach ($activefiles as $key => $value) {
                $trackids[$key] = TrackingData::select(DB::raw('max(track_id) as track_id , fk_file_id'))->where('trackingdata.fk_file_id',$value->file_id)->first();                
            }
            foreach ($trackids as $key => $value) {
                $depnames[$key] = TrackingData::join('departments','departments.department_id','trackingdata.fk_department_id')->where('track_id',$value->track_id)->first();
                // echo $value->fk_file_id;
            }
            // die();
            // dd($activefiles , $depnames);

            $data = array(
                'activefiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->join('departments','trackingdata.fk_department_id','departments.department_id')->where('status','active')->orderBy('trackingdata.created_at','DESC')->groupBy('filedata.reference_no')->get(),
                'finishedfiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->join('departments','trackingdata.fk_department_id','departments.department_id')->where('status','finished')->orderBy('trackingdata.created_at','DESC')->groupBy('filedata.reference_no')->get(),
                'pendingfiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->join('departments','trackingdata.fk_department_id','departments.department_id')->where('status','pending')->orderBy('trackingdata.created_at','DESC')->groupBy('filedata.reference_no')->get(),
                'useraddedfiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->join('departments','trackingdata.fk_department_id','departments.department_id')->where('created_by',Auth::user()->user_id)->orderBy('trackingdata.created_at','DESC')->groupBy('filedata.reference_no')->get(),
                'referredfiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->join('departments','trackingdata.fk_department_id','departments.department_id')->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->orderBy('trackingdata.created_at','DESC')->groupBy('filedata.reference_no')->get(),
                // 'otherfiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->where('trackingdata.fk_position_id','!=',Auth::user()->fk_pos_id)->orwhere('trackingdata.fk_department_id','!=',Auth::user()->fk_department_id)->where('created_by','!=',Auth::user()->user_id)->get()->orderBy('trackingdata.created_at','ASC')->groupBy('trackingdata.fk_file_id')
            );
            // dd($data);
            return $data;
        }else{
            $data = array(
                'useraddedfiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->join('departments','trackingdata.fk_department_id','departments.department_id')->where('created_by',Auth::user()->user_id)->orderBy('trackingdata.created_at','DESC')->groupBy('filedata.reference_no')->get(),
                'referredfiles' => FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->join('departments','trackingdata.fk_department_id','departments.department_id')->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->orderBy('trackingdata.created_at','DESC')->groupBy('filedata.reference_no')->get(),
            );
            return $data;
            // return FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->orWhere('trackingdata.fk_user_id',Auth::user()->user_id)->get();
        }
        
    }

    public static function getFileRefToUpdate(){
        if(Auth::user()->fk_role_id == 1){
            return FilesData::select('file_id','reference_no')->groupBy('reference_no')->where('status','!=','finished')->get();
        }else{
            return FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->select('file_id','reference_no')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->where('status','!=','finished')->orWhere('trackingdata.fk_user_id',Auth::user()->user_id)->groupBy('reference_no')->get();
        }
        
    }

    public static function getFileRef(){
        if(Auth::user()->fk_role_id == 1){
            return FilesData::select('file_id','reference_no')->groupBy('reference_no')->get();
        }else{
            return FilesData::join('trackingdata','filedata.file_id','trackingdata.fk_file_id')->select('file_id','reference_no')->where('trackingdata.fk_department_id',Auth::user()->fk_department_id)->where('trackingdata.fk_position_id',Auth::user()->fk_pos_id)->orWhere('trackingdata.fk_user_id',Auth::user()->user_id)->groupBy('reference_no')->get();
        }
        
    }

    public static function saveFileData($request){
        $filedata = new FilesData;
        $filedata->date_added = date('Y-m-d');
        $filedata->status = "active";
        $filedata->created_by = Auth::user()->user_id;
        $filedata->reference_no = $request->ref_initial .'-'. $request->ref_no;
        $filedata->fill($request->all());
        $filedata->save();
        return FilesData::orderBy('created_at', 'DESC')->select('file_id')->first();
        
    }

    public static function checkUpdateId($request){
        if(FilesData::find($request->file_id)){
            return true;
        }
    }

    public static function changeStatusToFin($id){
        $file = FilesData::find($id);
        $file->status = 'finished';
        $file->date_finished = date('Y-m-d');
        $file->finished_by = Auth::user()->user_id;
        $file->save();
    }
    public static function changeStatusToAct($id){
        $file = FilesData::find($id);
        $file->status = 'active';
        $file->date_finished = null;
        $file->finished_by = null;
        $file->save();
    }
    public static function changeStatusToVisible($id){
        $file = FilesData::find($id);
        $file->date_recieved = date('Y-m-d');
        $file->save();
    }
}
